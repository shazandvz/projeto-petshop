USE uppet;
ALTER TABLE consultas ADD COLUMN diagnostico TEXT;